<?php

/* Create Icon List Array
- - - - - - - - - - - - - - - - - - - - - - - - - - */
function wpvi_icon_list() {
	$fa4_icons = array('magicwand','painting','penruler','photos','scalpel','arrow-left','arrow-right','award','brush','brush-small','camera','can','cart','diamond','eye','feather','filter','flag','frame','globe','glue','graffiti','hand','heart','ink','key','keyboard','landscape','laptop','leaf','link','magnet','mail','mailbox','marker','message','microphone','monitor','monkey','mouse','movietape','mug','office','palette','pen','pencil','penhead','phone','pin','roller','ruler','scissors','search','stamp','stand','staple','star','triangle','user'
	);

	sort($fa4_icons);
	return $fa4_icons;
}

